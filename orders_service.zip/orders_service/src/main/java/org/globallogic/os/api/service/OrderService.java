package org.globallogic.os.api.service;

import org.globallogic.os.api.common.Payment;
import org.globallogic.os.api.common.Transactionrequest;
import org.globallogic.os.api.common.Transactionresponse;
import org.globallogic.os.api.entity.Order;
import org.globallogic.os.api.repository.orderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class OrderService {

	@Autowired
	private orderRepository repository;

	@Autowired
	private RestTemplate template;

	public Transactionresponse saveOrder(Transactionrequest request) {
		String response = "";
		Order order = request.getOrder();
		Payment payment = request.getPayment();
		payment.setOrderId(order.getId());
		payment.setAmount(order.getPrice());
		// Rest call

		@SuppressWarnings("unused")
		Payment paymentResponse = template.postForObject("http://localhost:9191/payment/doPayment", payment,
				Payment.class);
		response = paymentResponse.getPaymentStatus().equals("success")
				? "Payment processing successful" + " and order placed"
				: "there is " + "failure order save to the cart";
		repository.save(order);
		return new Transactionresponse(order,paymentResponse.getAmount(),
				paymentResponse.getTransactionId(),response
				);

	}
}
