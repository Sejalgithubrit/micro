package org.globallogic.os.api.common;

import org.globallogic.os.api.entity.Order;

public class Transactionrequest {

	//Order-Payment
	private Order order;//saved
	private Payment payment;//saved
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	public Transactionrequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transactionrequest(Order order, double d, String string, Payment payment) {
		super();
		this.order = order;
		this.payment = payment;
	}
	
}
