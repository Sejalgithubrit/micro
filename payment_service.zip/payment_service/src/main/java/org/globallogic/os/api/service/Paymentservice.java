package org.globallogic.os.api.service;

import java.util.Random;
import java.util.UUID;

import org.globallogic.os.api.entity.Payment;
import org.globallogic.os.api.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Paymentservice {

	@Autowired
	private PaymentRepository repository;
//making the payment
	public Payment doPayment(Payment payment) {
		//calling the method to check payment is success
		payment.setPaymentStatus(paymentProcessing());
		payment.setTransactionId(UUID.randomUUID().toString());
		return repository.save(payment);
	}
	
	public String paymentProcessing() {
		//api should be 3rd party gateway(Paytm,Phonepay)
		return new Random().nextBoolean() ?"success": "false";
	}
}
